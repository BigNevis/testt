/**
 * enumarion de apps
 */
export enum CompanyName {
  ACCIONA="ACCIONA", IGM="IGM", FLOCK="FLOCK"
}
