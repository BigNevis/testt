/**
 * base DTO
 */
export interface BaseDTO {
}
