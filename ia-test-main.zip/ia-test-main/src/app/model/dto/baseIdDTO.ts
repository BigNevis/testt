/**
 * base DTO con id
 */
import {BaseDTO} from "./baseDTO";

export interface BaseIdDTO extends BaseDTO {
  id:string;
}
