export interface PopupData {
  dto: any;
  functionToCall: ()=>void;
}
