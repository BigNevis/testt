export const environment = {
  production: true,
  SERVER: "",
};
