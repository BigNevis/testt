/**
 * configuracion para desarrollo local contra backend de QA
 */
export const environment = {
  production: false,
  SERVER: "https://appqa.igm.com.ar",
};
