/**
 * configuracion productiva para pwa local
 */
export const environment = {
  production: true,
  SERVER: "http://localhost:8080/rrhh",
};
